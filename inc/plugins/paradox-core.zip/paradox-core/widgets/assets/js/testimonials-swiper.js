jQuery(window).on("elementor/frontend/init", () => {
            new Swiper(".ts-swiper", {
                effect: "cards",
                grabCursor: true,
            });
});