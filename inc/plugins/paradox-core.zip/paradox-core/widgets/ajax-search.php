<?php
class Elementor_paradox_Search_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'َsearch';
	}

	public function get_title() {
		return esc_html__( 'جستجو ایجکس', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-search-bold';
	}

	public function get_categories() {
		return [ 'paradox-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
            'paradox_search_section',
            [
               'label' => esc_html__( 'Search', 'paradox-core' ),
			   'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );

		 $this->add_control(
			'icon_search',
			[
				'label' => esc_html__( 'آیکون سرچ', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-search',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'search_typography',
				'selector' => '{{WRAPPER}} .ajax_search_form input[type="text"],.btn.btn-search',
			]
		);

         $this->add_control(
            'paradox_search_input',
            [
               'label' => __( 'متن نگه دارنده ی جستجو', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::TEXT,
               'default' => __( 'چی میخوای یاد بگیری..؟'),
   
            ]
         );
		 $this->add_control(
			'search_txt_color',
			[
				'label' => esc_html__( 'رنگ متن سرچ', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn.btn-search' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ajax_search_form input[type="text"]::placeholder' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ajax_search_form input[type="text"]' => 'color: {{VALUE}}',
				],
			]
		);
		 $this->add_control(
			'search_bg_color',
			[
				'label' => esc_html__( 'رنگ پس زمینه', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .search-form-ajax,.ajax_search_form input[type="text"]' => 'background-color: {{VALUE}}',
				],
			]
		);

         $this->add_control(
			'button_bg_color',
			[
				'label' => esc_html__( 'رنگ پس زمینه دکمه', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn.btn-search' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_align',
			[
				'label' => esc_html__( 'موقعیت آیکون', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'چپ', 'paradox-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'row-reverse' => [
						'title' => esc_html__( 'راست', 'paradox-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .search-form-ajax' => 'flex-direction:{{VALUE}};',
				],
			]
		);
		$this->add_control(
			'search_height',
			[
				'label' => esc_html__( 'ارتفاع سرچ باکس', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 5,
				'max' => 200,
				'step' => 1,
				'default' => 70,
				'selectors' => [
					'{{WRAPPER}} .search-form-ajax' => 'height:{{VALUE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'search_btn_padding',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'فاصله داخلی دکمه', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ajax_search_form button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'search_padding',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'فاصله داخلی سرچ', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .search-form-ajax' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'search_radius',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'انحنا لبه ها', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .search-form-ajax,.ajax_search_form input[type="text"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


         $this->end_controls_section();

   	  }
   
	protected function render(){ 

    $settings = $this->get_settings_for_display(); ?>

    <form class="ajax_search_form" id="head-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <div class="search-form-ajax">
            <input autocomplete="off" data-swplive="true" name="s" type="text" class="form-control search-input" placeholder="<?php echo esc_html($settings['paradox_search_input']); ?>" required>
                <button class="btn btn-search" type="submit" aria-label="<?php echo __("جستجو", 'paradox-core'); ?>">
                    <i class="<?php echo esc_attr($settings['icon_search']['value']); ?>"></i>
                </button>
        </div>
    </form>

        <?php
	}
    
}
