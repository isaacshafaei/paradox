<?php
class Elementor_paradox_Menu_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'danesh-menu';
	}

	public function get_title() {
		return esc_html__( 'منو اصلی', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-menu-toggle';
	}

	public function get_categories() {
		return [ 'paradox-header-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
            'paradox_search_section',
            [
               'label' => esc_html__( 'Menu', 'paradox-core' ),
			   'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );

		 $this->add_control(
			'login_button_txt_color',
			[
				'label' => esc_html__( 'رنگ متن', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .site-navigation.paradox-navigation >ul>li> a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => esc_html__( 'رنگ پس زمینه', 'textdomain' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .site-navigation.paradox-navigation',
			]
		);

		$this->add_responsive_control(
			'login_btn_margin',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'فاصله خارجی دکمه', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .site-navigation.paradox-navigation' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'login_btn_padding',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'فاصله داخلی', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .site-navigation.paradox-navigation' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'login_btn_border_radius',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'انحنای دکمه', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .site-navigation.paradox-navigation' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border_login',
				'label' => esc_html__( 'حاشیه', 'paradox-core' ),
				'selector' => '{{WRAPPER}} .site-navigation.paradox-navigation',
			]
		);

		$this->add_control(
			'menu_align',
			[
				'label' => esc_html__( 'موقعیت منو', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'چپ', 'paradox-core' ),
						'icon' => 'eicon-text-align-left',
					],
                    'center' => [
						'title' => esc_html__( 'وسط', 'paradox-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'راست', 'paradox-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .site-navigation.paradox-navigation> ul' => 'justify-content:{{VALUE}};',
				],
			]
		);

		$this->add_control(
			'mobile_menu_align',
			[
				'label' => esc_html__( 'موقعیت منو در موبایل', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'چپ', 'paradox-core' ),
						'icon' => 'eicon-text-align-left',
					],
                    'center' => [
						'title' => esc_html__( 'وسط', 'paradox-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'راست', 'paradox-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .menu_element_hamburger' => 'justify-content:{{VALUE}};',
				],
			]
		);

         $this->end_controls_section();

   	  }
   
	protected function render(){ 

    $settings = $this->get_settings_for_display(); ?>
<?php
$menu = wp_nav_menu(
    array(
        'theme_location' => 'main-menu',
        'container' => false,
        'menu_class' => 'menu',
        'echo' =>false,
        'walker' => new paradoxFrontendWalker(),
    )
);
?>
<div class="off-canvas-overlay"></div>
<nav class="site-navigation paradox-navigation" role="navigation">
    <?php 
        if(has_nav_menu('main-menu')){
            echo wp_kses_post($menu);
        }
    ?>
</nav>
<div class="menu_element_hamburger">
	<a href="#" class="mobile-nav-toggle">
			<span class="the-icon"></span>
	</a>
</div>
<?php 
	}
    
}
