<?php
class Elementor_paradox_Login_Button_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'login-button';
	}

	public function get_title() {
		return esc_html__( 'دکمه ورود', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_categories() {
		return [ 'paradox-header-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
            'paradox_search_section',
            [
               'label' => esc_html__( 'User Button', 'paradox-core' ),
			   'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );

		 $this->start_controls_tabs(
			'search_btn_style_tabs'
		);
		
		$this->start_controls_tab(
			'style_before_login_tab',
			[
				'label' => esc_html__( 'قبل از لاگین', 'textdomain' ),
			]
		);

		 $this->add_control(
			'login_button_txt_color',
			[
				'label' => esc_html__( 'رنگ متن', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .button_link.user_logged_in' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => esc_html__( 'رنگ پس زمینه', 'textdomain' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .button_link.user_logged_in',
			]
		);

		$this->add_responsive_control(
			'login_btn_margin',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'فاصله خارجی دکمه', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .button_link.user_logged_in' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'login_btn_padding',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'فاصله داخلی', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .button_link.user_logged_in' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'login_btn_border_radius',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'انحنای دکمه', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .button_link.user_logged_in' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border_login',
				'label' => esc_html__( 'حاشیه', 'paradox-core' ),
				'selector' => '{{WRAPPER}} .button_link.user_logged_in',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_after_login_tab',
			[
				'label' => esc_html__( 'بعد از لاگین', 'textdomain' ),
			]
		);

		$this->add_control(
			'login_button_txt_color_after_login',
			[
				'label' => esc_html__( 'رنگ متن', 'paradox-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .register-modal-opener.login-button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background_after_login',
				'label' => esc_html__( 'رنگ پس زمینه', 'textdomain' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .register-modal-opener.login-button',
			]
		);

		$this->add_responsive_control(
			'login_btn_margin_after_login',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'فاصله خارجی دکمه', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .register-modal-opener.login-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'login_btn_padding_after_login',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'فاصله داخلی', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .register-modal-opener.login-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'login_btn_border_radius_after_login',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'انحنای دکمه', 'paradox-core' ),
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .register-modal-opener.login-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border_login_after_login',
				'label' => esc_html__( 'حاشیه', 'paradox-core' ),
				'selector' => '{{WRAPPER}} .register-modal-opener.login-button',
			]
		);

		$this->end_controls_tab();
		
		$this->end_controls_tabs();

         $this->end_controls_section();

   	  }
   
	protected function render(){ 

    $settings = $this->get_settings_for_display(); ?>

<?php 
$before_text_button = 'ورود و ثبت نام';
if(class_exists('Redux')){
    $button_link = paradox_settings('button_link');
    if($button_link=='custom_link'){
        $before_text_button = (paradox_settings('custom_button_text'))?paradox_settings('custom_button_text'):'ورود و ثبت نام';
        $before_link_button = (paradox_settings('custom_button_link'))?paradox_settings('custom_button_link'):'#';
    }
}
?>
			<div class="button_link <?php echo (is_user_logged_in())?'user_logged_in':''; ?>">
                    <?php
                    if(is_plugin_active('digits/digit.php')){
                        if(is_user_logged_in()){
                            get_template_part('/inc/templates/header/user-menu'); 
                        }else{
                            echo do_shortcode('[dm-modal]'); 
                        }    
                    }else{
                        if(is_user_logged_in()){
                            get_template_part('/inc/templates/header/user-menu'); 
                        }else{
                            get_template_part('/inc/templates/header/header-button'); 
                        }    
                    }
                     ?>
			</div>

        <?php
	}
    
}
