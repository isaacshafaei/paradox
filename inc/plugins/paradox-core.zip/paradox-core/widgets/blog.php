<?php
class Elementor_paradox_Blog_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'َBlog';
	}

	public function get_title() {
		return esc_html__( 'وبلاگ', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-document-file';
	}

	public function get_categories() {
		return [ 'paradox-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {
        $this->start_controls_section(
            'blog_section',
            [
               'label' => esc_html__( 'Blog', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );
   
   
         $this->add_control(
            'category',
            [
               'label' => esc_html__( 'Category', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT2,
               'title' => esc_html__( 'Select a category', 'paradox-core' ),
               'multiple' => true,
               'options' => get_the_post_category(),
            ]
         );
   
         $this->end_controls_section();   

   	  }
   
	protected function render(){ 
    $settings = $this->get_settings_for_display();
    
   //  first query
    $args = array(
      'post_type' => 'post',
      'posts_per_page' => 1,
      'post_status' => 'publish',
   );

   // second Query
   $args2 = array(
      'post_type' => 'post',
      'posts_per_page' => 2,
      'offset' => 1,
   );

      if(!empty($settings['category'])){
         $args = array(
            'post_type' => 'post',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'tax_query' => array(
               array(
                  'taxonomy' => 'category',
                  'terms' => $settings['category'],
               )
            ),
         );

         $args2 = array(
            'post_type' => 'post',
            'posts_per_page' => 2,
            'offset' => 1,
            'post_status' => 'publish',
            'tax_query' => array(
               array(
                  'taxonomy' => 'category',
                  'terms' => $settings['category'],
               )
            ),
         );
   
      }
     
      $main_query = new \WP_Query($args);
      $other_query = new \WP_Query($args2);
    ?>

            <div class="blog_widget">
                <div class="grid_container">
                  <?php while ($main_query -> have_posts()) : $main_query -> the_post(); ?>
                     <div class="main_right">
                        <a href="<?php the_permalink(); ?>">
                           <?php the_post_thumbnail('paradox-820x550'); ?>
                           <div class="blog_post_inner">
                              <span class="category"><?php echo get_the_category(get_the_ID())[0]->name; ?></span>
                              <h2 class="title"><?php echo the_title(); ?></h2>
                           </div>
                        </a>
                     </div>
                  <?php endwhile; ?>
                  <?php while ($other_query -> have_posts()) : $other_query -> the_post(); ?>
                     <div class="left_top">
                        <a href="<?php the_permalink(); ?>">
                           <?php the_post_thumbnail('paradox-410x260'); ?>
                           <div class="blog_post_inner">
                              <span class="category"><?php echo get_the_category(get_the_ID())[0]->name; ?></span>
                              <h2 class="title"><?php echo the_title(); ?></h2>
                           </div>
                        </a>
                     </div>
                  <?php endwhile; ?>
                </div>
            </div>
        <?php
	}
    
}
