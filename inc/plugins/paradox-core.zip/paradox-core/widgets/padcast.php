<?php
class Elementor_paradox_Padcast_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'َPacast';
	}

	public function get_title() {
		return esc_html__( 'پادکست', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-headphones';
	}

	public function get_categories() {
		return [ 'paradox-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {
        $this->start_controls_section(
            'padcast_section',
            [
               'label' => esc_html__( 'تنظیمات ', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );
   
         $this->add_control(
            'padcast_category',
            [
               'label' => esc_html__( 'دسته بندی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT2,
               'title' => esc_html__( 'یک دسته بندی را انتخاب کنید', 'paradox-core' ),
               'multiple' => true,
               'options' => get_the_post_category(),
            ]
         );

         $this->add_control(
            'padcast_columns',
            [
               'label' => __( 'ستون ها', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => '3',
               'options' => [
                  '4'  => __( '4 ستونه', 'paradox-core' ),
                  '3' => __( '3 ستونه', 'paradox-core' ),
                  '2' => __( '2 ستونه', 'paradox-core' ),
               ],
            ]
         );

         $this->add_control(
            'number_of_padcast',
            [
               'label' => __( 'تعداد آیتم ها', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SLIDER,
               'range' => [
                  'no' => [
                     'min' => 0,
                     'max' => 100,
                     'step' => 1,
                  ],
               ],
               'default' => [
                  'size' => 3,
               ]
            ]
         );

         $this->add_control(
            'padcast_order',
            [
               'label' => __( 'مرتب سازی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => 'ASC',
               'options' => [
                  'none'  => __( 'هیچ کدام', 'paradox-core' ),
                  'ASC'  => __( 'صعودی', 'paradox-core' ),
                  'DESC' => __( 'نزولی', 'paradox-core' )
               ],
            ]
         );
   
         $this->end_controls_section();   

         $this->start_controls_section(
            'padcast_carousel_section',
            [
               'label' => esc_html__( 'تنظیمات کروسل', 'paradox-core' ),
               'tab' => \Elementor\Controls_Manager::SECTION,
            ]
         );

         $this->add_control(
            'padcast_pagination',
            [
               'label' => __( 'صفحه گذاری اسلایدر', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'default' => 'false',
   
            ]
         );
   
         $this->add_control(
            'padcast_navigation',
            [
               'label' => __( 'فلش های ناوبری', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'default' => 'false',
   
            ]
         );
   
         $this->add_control(
            'padcast_loop',
            [
               'label' => __( 'حلقه کروسل', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'default' => 'true',
   
            ]
         );
   
         $this->add_control(
            'padcast_autoplay',
            [
               'label' => __( 'اجرای خودکار اسلایدر', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'default' => 'false',
   
            ]
         );

         $this->end_controls_section(); 

         $this->start_controls_section(
            'padcast_style_section',
            [
               'label' => esc_html__( 'تنظیمات استایل', 'paradox-core' ),
               'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
         );

         $this->add_control(
            'padcast_txt_color',
            [
               'label' => esc_html__( 'رنگ متن', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .padcast_item h3 a' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .top_sec' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name' => 'padcast_background',
               'label' => esc_html__( 'رنگ پس زمینه', 'paradox-core' ),
               'types' => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .padcast_item',
            ]
         );

         $this->end_controls_section();   

   	  }
   
	protected function render(){ 
   $settings = $this->get_settings_for_display();
   $carousel_data = array();
   $carousel_data['slider-items'] = $settings['padcast_columns'];
   $carousel_data['pagination'] = ($settings['padcast_pagination'] =='yes')?'true':'false';
   $carousel_data['navigation'] = ($settings['padcast_navigation'] == 'yes')?'true':'false';
   $carousel_data['loop'] = ($settings['padcast_loop'] == 'yes')?'true':'false';
   $carousel_data['autoplay'] = ($settings['padcast_autoplay'] == 'yes')?'true':'false';

   $category = $settings['padcast_category'];
   $perfix = 'paradox_';
   $args = array(
      'post_type' => 'post',
      'posts_per_page' => $settings['number_of_padcast']['size'],
      'order' => $settings['padcast_order'],
      'tax_query' => array(
          'relation' => 'AND',
          array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => 'post-format-audio'
          )
      ),
  );

  if(!empty($category)){
   $args = array(
       'post_type' => 'post',
       'posts_per_page' => $settings['number_of_padcast']['size'],
       'order' => $settings['padcast_order'],
       'tax_query' => array(
           'relation' => 'AND',
           array(
             'taxonomy' => 'category',
             'terms' => $category,
             'operator'  => 'IN',
           )

       ),
   );
}

   $padcasts = new \WP_Query($args);
   ?>
<div class="padcast_widget">
   <div class="padcast_wrapper">
       <div class="owl-carousel owl-theme owl-padcast">
         <?php
         while ( $padcasts->have_posts() ) : $padcasts->the_post();
         $padcast_number = get_post_meta(get_the_id(),$perfix.'padcast_number',true);
         $padcast_time = get_post_meta(get_the_id(),$perfix.'padcast_time',true);
         $padcast_squre_image = get_post_meta(get_the_id(),$perfix.'square_padcast_image',true);    
         ?>
         <div class="item">
               <div class="padcast_item">
                  <div class="top_sec">
                     <span class="number">
                     <i class="fas fa-microphone-alt"></i>
                     <?php echo esc_html($padcast_number); ?>
                     </span>
                     <?php if($padcast_time){ ?>
                     <span class="time">
                     <i class="far fa-clock"></i>
                        <?php echo esc_html($padcast_time); ?>
                     </span>
                     <?php } ?>
                  </div>
                  <h3 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                  <div class="botoom_sec">
                     <a class="listen" href="<?php the_permalink(); ?>">
                        برای گوش دادن کلیک کنید
                        <i aria-hidden="true" class="fas fa-long-arrow-alt-left"></i>
                     </a>
                     <a class="image_padcast" href="<?php the_permalink(); ?>"><?php
                     if(!empty($padcast_squre_image)){ ?>
                        <img src="<?php echo esc_attr($padcast_squre_image); ?>" alt="<?php echo esc_attr(the_title()); ?>">
                  <?php
                     }else{
                        the_post_thumbnail('paradox-80x80'); 
                     }
                     ?></a>
                  </div>
               </div>
            </div>
         <?php
         endwhile;
         wp_reset_postdata();
         ?>
      </div>
   </div>
</div>
<script>
   jQuery(function($){
           $('.owl-carousel').owlCarousel({
            loop:<?php echo $carousel_data['loop']; ?>,
            margin:20,
            nav:<?php echo $carousel_data['navigation']; ?>,
            dots:<?php echo $carousel_data['pagination']; ?>,
            rtl:true,
            autoplay:<?php echo $carousel_data['autoplay']; ?>,
            autoplayTimeout:3000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:<?php echo $carousel_data['slider-items']; ?>
                }
            }
        });
      });//End Jquery
</script>
 <?php
	}
}
?>