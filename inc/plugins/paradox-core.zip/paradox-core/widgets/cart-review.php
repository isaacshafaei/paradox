<?php
class Elementor_paradox_Cart_Review_Widget extends \Elementor\Widget_Base {

   public function __construct($data = [], $args = null)
   {
       parent::__construct($data, $args);

       global $theme_version;
       $theme_obj = wp_get_theme();
       $theme_version = $theme_obj->get('Version');
       $plugin_path = plugin_dir_url( __FILE__ );

       wp_register_style('paradox-core-testimonials-swiper-css',$plugin_path.'assets/css/swiper.min.css');
       wp_register_script('paradox-core-testimonials-swiper-js', $plugin_path.'assets/js/swiper.min.js', ['elementor-frontend'], $theme_version, true);
       wp_register_script('paradox-core-testimonials-swiper-swiper-js',$plugin_path.'assets/js/testimonials-swiper.js', ['elementor-frontend'], $theme_version, true);
   }

	public function get_name() {
		return 'Cart_Review';
	}

	public function get_title() {
		return esc_html__( 'نظرات کارتی', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-review';
	}

	public function get_categories() {
		return [ 'paradox-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
            'products_section',
            [
               'label' => esc_html__( 'تنظیمات', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );
         $repeater = new \Elementor\Repeater();

         $repeater->add_control(
             'image',
             [
                 'label' => __('انتخاب تصویر', 'paradox-core'),
                 'type' => \Elementor\Controls_Manager::MEDIA,
                 'default' => [
                     'url' => \Elementor\Utils::get_placeholder_image_src(),
                 ],
             ]
         );
 
         $repeater->add_control(
             'name',
             [
                 'label' => __('نام', 'paradox-core'),
                 'type' => \Elementor\Controls_Manager::TEXT,
 
             ]
         );
 
         $repeater->add_control(
             'designation',
             [
                 'label' => __('توضیحات', 'paradox-core'),
                 'type' => \Elementor\Controls_Manager::TEXT
             ]
         );
 
         $repeater->add_control(
             'testimonial',
             [
                 'label' => __('نظر', 'paradox-core'),
                 'type' => \Elementor\Controls_Manager::TEXTAREA
             ]
         );
 
 
         $this->add_control(
             'testimonial_list',
             [
                 'label' => __('Testimonial List', 'paradox-core'),
                 'type' => \Elementor\Controls_Manager::REPEATER,
                 'fields' => $repeater->get_controls(),
                 'title_field' => '{{{name}}}',
 
             ]
         );
         $this->end_controls_section(); 

         $this->start_controls_section(
            'card_style_section',
            [
               'label' => esc_html__( 'تنظیمات استایل', 'paradox-core' ),
               'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
         );

         $this->add_control(
            'card_txt_color',
            [
               'label' => esc_html__( 'رنگ متن', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .desc_of_testmonial' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .name-and-job' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_student' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_price del' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_price span' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_list_item_desc' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name' => 'card_background',
               'label' => esc_html__( 'رنگ پس زمینه', 'paradox-core' ),
               'types' => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .testemonial_wrapper',
            ]
         );

         $this->end_controls_section(); 
   
   	  }
   
	protected function render(){ 

      // get our input from the widget settings.
      $settings = $this->get_settings_for_display();
      ?>

      <div class="swiper ts-swiper">
          <div class="swiper-wrapper">
              <?php foreach ($settings['testimonial_list'] as $setting): ?>
                  <div class="swiper-slide ts-swiper-item">
                     <div class="testemonial_wrapper">
                        <p class="desc_of_testmonial"><?php echo $setting['testimonial'] ?></p>
                        <div class="other_of_testmonial">
                           <img src="<?php echo $setting['image']['url'] ?>" alt="">
                           <div class="name-and-job">
                                 <p class="name"><?php echo $setting['name'] ?></p>
                                 <p class="job"><?php echo $setting['designation'] ?></p>
                           </div>
                        </div>
                     </div>
                  </div>
              <?php endforeach; ?>
          </div>
      </div>

      <?php
	}

   public function get_style_depends()
   {

       return ['paradox-core-testimonials-swiper-css'];

   }

   public function get_script_depends()
   {
       return ['paradox-core-testimonials-swiper-js', 'paradox-core-testimonials-swiper-swiper-js'];
   }
}
