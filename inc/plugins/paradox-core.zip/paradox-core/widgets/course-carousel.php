<?php
class Elementor_paradox_Course_Carousel_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Course_Carousel';
	}

	public function get_title() {
		return esc_html__( 'کروسل دوره ها', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	public function get_categories() {
		return [ 'paradox-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
            'products_section',
            [
               'label' => esc_html__( 'Carousel Products', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );
   
         $this->add_control(
            'columns',
            [
               'label' => __( 'ستون ها', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => '3',
               'options' => [
                  '4'  => __( '4 ستونه', 'paradox-core' ),
                  '3' => __( '3 ستونه', 'paradox-core' ),
                  '2' => __( '2 ستونه', 'paradox-core' ),
               ],
            ]
         );
   
         $this->add_control(
            'pagination',
            [
               'label' => __( 'صفحه گذاری اسلایدر', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'default' => 'false',
   
            ]
         );
   
         $this->add_control(
            'navigation',
            [
               'label' => __( 'فلش های ناوبری', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'default' => 'yes',
   
            ]
         );
   
         $this->add_control(
            'loop',
            [
               'label' => __( 'حلقه کروسل', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'default' => 'yes',
   
            ]
         );
   
         $this->add_control(
            'autoplay',
            [
               'label' => __( 'اجرای خودکار اسلایدر', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'default' => 'yes',
   
            ]
         );
   
         $this->add_control(
            'category',
            [
               'label' => esc_html__( 'دسته بندی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT2,
               'title' => esc_html__( 'Select a category', 'paradox-core' ),
               'multiple' => true,
               'options' => get_the_product_category(),
            ]
         );
   
         $this->add_control(
            'number_of_items',
            [
               'label' => __( 'تعداد آیتم ها', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SLIDER,
               'range' => [
                  'no' => [
                     'min' => 0,
                     'max' => 100,
                     'step' => 1,
                  ],
               ],
               'default' => [
                  'size' => 3,
               ]
            ]
         );
   
         $this->add_control(
            'order',
            [
               'label' => __( 'مرتب سازی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => 'DESC',
               'options' => [
                  'ASC'  => __( 'صعودی', 'paradox-core' ),
                  'DESC' => __( 'نزولی', 'paradox-core' )
               ],
            ]
         );

         $this->add_control(
            'carousel_txt_color',
            [
               'label' => esc_html__( 'رنگ متن', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .courses-holder .entry_title a' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-holder .course_student i' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-holder .course_student' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-holder .course_price del' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-holder .course_price span' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-holder .course_list_item_desc' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name' => 'carousel_background',
               'label' => esc_html__( 'رنگ پس زمینه', 'paradox-core' ),
               'types' => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .related_post.course_item',
            ]
         );

         $this->end_controls_section();
   
   	  }
   
	protected function render(){ 

      // get our input from the widget settings.
      $settings = $this->get_settings_for_display();

	  $carousel_data = array();
	  $carousel_data['data-slider-items'] = $settings['columns'];
	  $carousel_data['data-pagination'] = ($settings['pagination'] =='yes')?'true':'false';
	  $carousel_data['data-navigation'] = ($settings['navigation'] == 'yes')?'true':'false';
	  $carousel_data['data-loop'] = ($settings['loop'] == 'yes')?'true':'false';
	  $carousel_data['data-autoplay'] = ($settings['autoplay'] == 'yes')?'true':'false';
	  ?>
      <div class="elementor-products products courses-holder">
	      <div class="owl-carousel owl-theme course-carousel">
         <?php
      $args = array(
         'post_type' => 'product',
         'posts_per_page' => $settings['number_of_items']['size'],
         'order' => $settings['order'],
         'post_status' => 'publish',
      );

         if(!empty($settings['category'])){
            $args = array(
               'post_type' => 'product',
               'posts_per_page' => $settings['number_of_items']['size'],
               'order' => $settings['order'],
               'post_status' => 'publish',
               'tax_query' => array(
                  array(
                     'taxonomy' => 'product_cat',
                     'terms' => $settings['category'],
                  )
               ),
            );
         }
       
         $products = new \WP_Query($args);

         /* Start the Loop */
         while ( $products->have_posts() ) : $products->the_post(); ?>


             <?php get_template_part( 'woocommerce/content-product-carousel' ); ?>


         <?php
         endwhile;
      wp_reset_postdata();
      ?>
      </div>
	  </div>
<script>
   jQuery(function($){
           //product carousel widget
           $('.course-carousel').owlCarousel({
            loop:<?php echo $carousel_data['data-loop']; ?>,
            margin:10,
            nav:<?php echo $carousel_data['data-navigation']; ?>,
            dots:<?php echo $carousel_data['data-pagination']; ?>,
            rtl:true,
            autoplay:<?php echo $carousel_data['data-autoplay']; ?>,
            autoplayTimeout:3000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:<?php echo $carousel_data['data-slider-items']; ?>
                }
            }
        });
      });//End Jquery
</script>
   <?php
	}
    
}
