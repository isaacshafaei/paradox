<?php
class Elementor_paradox_Pelleh_Blog_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'َPelleh_Blog';
	}

	public function get_title() {
		return esc_html__( 'بلاگ پله ای', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-masonry';
	}

	public function get_categories() {
		return [ 'paradox-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {
        $this->start_controls_section(
            'blog_pelleh_section',
            [
               'label' => esc_html__( 'تنظیمات ', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );
   
         $this->add_control(
            'pelleh_category',
            [
               'label' => esc_html__( 'دسته بندی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT2,
               'title' => esc_html__( 'یک دسته بندی را انتخاب کنید', 'paradox-core' ),
               'description' => esc_html__( 'نکته : برای نمایش بهتر لطفاً سعی کنید مقالاتی رو انتخاب کنید که اندازه تصاویر و تعداد کاراکترهای عنوان مقاله ها یکسان باشند', 'paradox-core' ),
               'multiple' => true,
               'options' => get_the_post_category(),
            ]
         );

         $this->add_control(
            'order',
            [
               'label' => __( 'مرتب سازی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => 'ASC',
               'options' => [
                  'none'  => __( 'هیچ کدام', 'paradox-core' ),
                  'ASC'  => __( 'صعودی', 'paradox-core' ),
                  'DESC' => __( 'نزولی', 'paradox-core' )
               ],
            ]
         );

         $this->add_control(
            'order_by',
            [
               'label' => __( 'مرتب سازی بر اساس', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'options' => [
                  'none'  => __( 'هیچ کدام', 'paradox-core' ),
                  'ID'  => __( 'ID', 'paradox-core' ),
                  'author' => __( 'نویسنده', 'paradox-core' ),
                  'title' => __( 'عنوان', 'paradox-core' ),
                  'name' => __( 'نام', 'paradox-core' ),
                  'type' => __( 'نوع', 'paradox-core' ),
                  'date' => __( 'تاریخ', 'paradox-core' ),
                  'modified' => __( 'ویرایش شده', 'paradox-core' ),
                  'parent' => __( 'والد', 'paradox-core' ),
                  'rand' => __( 'رندوم', 'paradox-core' ),
                  'comment_count' => __( 'تعداد نظرات', 'paradox-core' ),
               ],
            ]
         );
   
         $this->end_controls_section();   

         $this->start_controls_section(
            'pelleh_style_section',
            [
               'label' => esc_html__( 'تنظیمات استایل', 'paradox-core' ),
               'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
         );

         $this->add_control(
            'pelleh_txt_color',
            [
               'label' => esc_html__( 'رنگ متن', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .pelleh_item h4' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .cat_author .author a' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name' => 'pelleh_background',
               'label' => esc_html__( 'رنگ پس زمینه', 'paradox-core' ),
               'types' => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .pelleh_item',
            ]
         );

         $this->add_control(
            'pelleh_cat_txt_color',
            [
               'label' => esc_html__( 'رنگ متن دسته بندی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .categoey a' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .cat_author .categoey' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name' => 'pelleh_cat_background',
               'label' => esc_html__( 'رنگ پس زمینه دسته بندی', 'paradox-core' ),
               'types' => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .cat_author .categoey',
            ]
         );

         $this->end_controls_section(); 


   	  }
   
	protected function render(){ 
   $settings = $this->get_settings_for_display();
   $category = $settings['pelleh_category'];

      $args = array(
         'post_type' => 'post',
         'posts_per_page' => 4,
         'post_status' => 'publish',
         'order' =>$settings['order'] ,
         'orderby' =>$settings['order_by'] ,
      );
     
         if(!empty($category)){
            $args = array(
               'post_type' => 'post',
               'posts_per_page' => 4,
               'post_status' => 'publish',
               'order' =>$settings['order'] ,
               'orderby' =>$settings['order_by'] ,
               'tax_query' => array(
                  array(
                     'taxonomy' => 'category',
                     'terms' => $category ,
                  )
               ),
            );
         }

   $blog = new \WP_Query($args);
   ?>
<div class="blog_pelle">
   <div class="blog_pelleh_wrapper">
<?php
       $count = 0;
       while ( $blog->have_posts() ) : $blog->the_post();
       $count++;
       ?>
            <div class="pelleh_item <?php echo ($count==1 || $count == 3)?'go_top':''; ?>">
               <div class="image_pelleh_post">
                  <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('paradox-280x160'); ?></a>
               </div>
               <a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
               <div class="cat_author">
                  <span class="author">
                  <?php echo get_avatar(get_the_author_meta('ID')); ?>
                     <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"> <?php echo get_the_author(); ?></a></span>
                     <span class="categoey">
                     <i class="fal fa-folders"></i>
                     <?php 
                     $categories = get_the_category();
                     if ( ! empty( $categories ) ) {
                         echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                     }
                     ?>
                  </span>               </div>
            </div>
       <?php
       endwhile;
       wp_reset_postdata();
       ?>
    </div>
 </div>
 <?php
	}
}
