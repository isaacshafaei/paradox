<?php
class Elementor_paradox_Course_List_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'Course_list';
	}

	public function get_title() {
		return esc_html__( 'لیست دوره ها', 'paradox-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'paradox-category' ];
	}

	public function get_keywords() {
		return [ 'paradox', 'پارادوکس' ];
	}

	protected function _register_controls() {

        $this->start_controls_section(
            'products_section',
            [
               'label' => esc_html__( 'Carousel List', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );
   
         $this->add_control(
            'course_list_style',
            [
               'label' => esc_html__( 'استایل لیست دوره ها', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => 'normal',
               'options' => [
                  'normal' => esc_html__( 'عادی', 'paradox-core' ),
                  'image-up' => esc_html__( 'بیرون زدن تصویر', 'paradox-core' ),
               ],
            ]
         );

         $this->add_control(
            'columns_list_width',
            [
               'label' => __( 'تعداد ستون', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => '31',
               'options' => [
                  '1'  => __( '1 ستونه', 'paradox-core' ),
                  '2' => __( '2 ستونه', 'paradox-core' ),
                  '3' => __( '3 ستونه', 'paradox-core' ),
                  '4' => __( '4 ستونه', 'paradox-core' ),
                  '5' => __( '5 ستونه', 'paradox-core' ),
                  '6' => __( '6 ستونه', 'paradox-core' ),
               ],
            ]
         );
      
         $this->add_control(
            'category',
            [
               'label' => esc_html__( 'دسته بندی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT2,
               'title' => esc_html__( 'Select a category', 'paradox-core' ),
               'multiple' => true,
               'options' => get_the_product_category(),
            ]
         );
   
         $this->add_control(
            'number_of_items',
            [
               'label' => __( 'تعداد آیتم ها', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SLIDER,
               'range' => [
                  'no' => [
                     'min' => 0,
                     'max' => 100,
                     'step' => 1,
                  ],
               ],
               'default' => [
                  'size' => 3,
               ]
            ]
         );
   		$this->add_control(
            'show_desc_item',
            [
               'label' => esc_html__( 'نمایش خلاصه دوره ها', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SWITCHER,
               'label_on' => esc_html__( 'نمایش', 'paradox-core' ),
               'label_off' => esc_html__( 'پنهان', 'paradox-core' ),
               'return_value' => 'yes',
               'default' => 'yes',
            ]
         );

         $this->add_control(
            'order',
            [
               'label' => __( 'مرتب سازی', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SELECT,
               'default' => 'DESC',
               'options' => [
                  'ASC'  => __( 'صعودی', 'paradox-core' ),
                  'DESC' => __( 'نزولی', 'paradox-core' )
               ],
            ]
         );
   
         $this->add_control(
            'course_list_txt_color',
            [
               'label' => esc_html__( 'رنگ متن', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::COLOR,
               'selectors' => [
                  '{{WRAPPER}} .courses-list .entry_title a' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_student i' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_student' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_price del' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_price span' => 'color: {{VALUE}}',
                  '{{WRAPPER}} .courses-list .course_list_item_desc' => 'color: {{VALUE}}',
               ],
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
               'name' => 'list_background',
               'label' => esc_html__( 'رنگ پس زمینه', 'paradox-core' ),
               'types' => [ 'classic', 'gradient', 'video' ],
               'selector' => '{{WRAPPER}} .related_post.course_item.course_list',
            ]
         );

         $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
               'name' => 'course_list_box_shadow',
               'label' => esc_html__( 'سایه باکس', 'paradox-core' ),
               'selector' => '{{WRAPPER}} .related_post.course_item.course_list',
            ]
         );

         $this->end_controls_section();

         $this->start_controls_section(
            'products_image_section',
            [
               'label' => esc_html__( 'تنظیمات تصویر', 'paradox-core' ),
               'type' => \Elementor\Controls_Manager::SECTION,
            ]
         );

         $this->add_responsive_control(
            'course_list_margin',
            [
               'type' => \Elementor\Controls_Manager::DIMENSIONS,
               'label' => esc_html__( 'فاصله خارجی تصویر', 'paradox-core' ),
               'size_units' => [ 'px', 'em', '%' ],
               'selectors' => [
                  '{{WRAPPER}} .products.courses-list .post_thumbnail img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

         $this->add_responsive_control(
            'course_list_padding',
            [
               'type' => \Elementor\Controls_Manager::DIMENSIONS,
               'label' => esc_html__( 'فاصله داخلی تصویر', 'paradox-core' ),
               'size_units' => [ 'px', 'em', '%' ],
               'selectors' => [
                  '{{WRAPPER}} .products.courses-list .post_thumbnail img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );

         $this->add_responsive_control(
            'course_list_border_radius',
            [
               'type' => \Elementor\Controls_Manager::DIMENSIONS,
               'label' => esc_html__( 'انحنای تصویر', 'paradox-core' ),
               'size_units' => [ 'px', 'em', '%' ],
               'selectors' => [
                  '{{WRAPPER}} .products.courses-list .post_thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
            ]
         );
         $this->end_controls_section();

   
   	  }
   
	protected function render(){ 

      // get our input from the widget settings.
      $settings = $this->get_settings_for_display();
	  ?>
      <div class="elementor-products products courses-list <?php echo esc_attr($settings['course_list_style']); ?>" style="grid-template-columns:repeat(<?php echo esc_attr($settings['columns_list_width']); ?>,1fr);">
         <?php
      $args = array(
         'post_type' => 'product',
         'posts_per_page' => $settings['number_of_items']['size'],
         'order' => $settings['order'],
         'post_status' => 'publish',
      );

         if(!empty($settings['category'])){
            $args = array(
               'post_type' => 'product',
               'posts_per_page' => $settings['number_of_items']['size'],
               'order' => $settings['order'],
               'post_status' => 'publish',
               'tax_query' => array(
                  array(
                     'taxonomy' => 'product_cat',
                     'terms' => $settings['category'],
                  )
               ),
            );
         }
       
         $products = new \WP_Query($args);

         /* Start the Loop */
         while ( $products->have_posts() ) : $products->the_post(); ?>
                  <article class="related_post course_item course_list">
                     <div class="post_thumbnail">
                        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('paradox-420x294'); ?></a>
                        <?php
                           global $product;

                              if ( $product->is_on_sale()) {

                              if ( ! $product->is_type( 'variable' ) ) {

                              $max_percentage = ( ( $product->get_regular_price() - $product->get_sale_price() ) / $product->get_regular_price() ) * 100;

                              } else {

                                 $max_percentage = 0;

                                 foreach ( $product->get_children() as $child_id ) {
                                 $variation = wc_get_product( $child_id );
                                 $price = $variation->get_regular_price();
                                 $sale = $variation->get_sale_price();
                                 if ( $price != 0 && ! empty( $sale ) ) $percentage = ( $price - $sale ) / $price * 100;
                                 if ( $percentage > $max_percentage ) {
                                 $max_percentage = $percentage;
                                 }
                                 }

                              }
                              echo "<div class='onsale_price'>";
                              echo "<span class='onsale_perc'>" . round($max_percentage) ."%</span>";
                              echo "<span class='sale_text'>تخفیف</span>";
                              echo "</div>";
                              }
                           ?>
                     </div>
                     <div class="post_content">
                        <h3 class="entry_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <?php 
                        if($settings['show_desc_item'] == true){ ?>
                        <p class="course_list_item_desc"><?php
                          echo esc_html(wp_trim_words(apply_filters( 'the_excerpt', $product->post->post_excerpt ), 12, '...' )); ?>
                        </p>
                        <?php } ?>
                        <div class="course_content_bottom">
                           <div class="course_student">
                              <i class="fal fa-users"></i>
                              <span><?php echo get_post_meta(get_the_ID(),'total_sales', true); ?></span>
                           </div>
                           <div class="course_price">
                              <?php woocommerce_template_loop_price(); ?>
                           </div>
                        </div>
                     </div>
                  </article>        

         <?php
         endwhile;
      wp_reset_postdata();
      ?>
	  </div>
   <?php
	}
    
}
