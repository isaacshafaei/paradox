jQuery(function($){

    //Lesson Item
    $( ".course_section.accordions,.accordion_wrapper" ).accordion({
        collapsible: true,
        active: false,
        animate: 200,
    });

    // Video popup
        $('.panel_column_left a.preview_button').click(function(event){
            event.preventDefault();
            var url = $(this).attr('href'); 

            $('.video_popup_wrrapper').fadeIn();
            $('body').find('.video_popup_wrrapper .video_popup_inner').html('<div class="spinner_loading"> <div class="double-bounce1"></div> <div class="double-bounce2"></div></div>');

        $.ajax({
        type: 'post',
        url:woocommerce_params['ajax_url'],
        data:{'action':'preview_video_ajax','url':url},
    
       success:function (response) {
          $('body').find('.video_popup_wrrapper .video_popup_inner').html('<video controls="" autoplay="" name="media"><source src="'+response+'" type="video/mp4"></video>');
           $('.video_popup_wrrapper').fadeIn();
       }
    });
    });
        $('.video_popup_overlay').click(function(event){
            $('.video_popup_wrrapper').fadeOut();
            $('body').find('.video_popup_wrrapper .video_popup_inner video').remove();
        });

        /**
         * courses Video popup 
         */
         $('a.play_btn').click(function(event){
            event.preventDefault();
            var url = $(this).attr('href');
        
            $('.video_popup_wrrapper').fadeIn();
            $('body').find('.video_popup_wrrapper .video_popup_inner').html('<div class="spinner_loading"> <div class="double-bounce1"></div> <div class="double-bounce2"></div></div>');
    
        $.ajax({
        type: 'post',
        url:woocommerce_params['ajax_url'],
        data:{'action':'preview_video_ajax','url':url},
    
       success:function (response) {
          $('body').find('.video_popup_wrrapper .video_popup_inner').html('<video controls="" autoplay="" name="media"><source src="'+response+'" type="video/mp4"></video>');
           $('.video_popup_wrrapper').fadeIn();
       }
    
    });
    });
    $('.video_popup_overlay').click(function(event){
        $('.video_popup_wrrapper').fadeOut();
        $('body').find('.video_popup_wrrapper .video_popup_inner video').remove();
    });

    });//End Jquery

    //Video Player
    var nav_link = document.querySelectorAll('.playlist .playlist_item');
    nav_link.forEach(item => {
        item.addEventListener('click',function(event){
            event.preventDefault();

            //stop that video is playing
            videoTag = document.querySelector('.main_video.show_active video');
            videoTag.pause();
            
            var url = item.getAttribute('href'); 

            //add and remove background style ---->
            let link_item = document.querySelectorAll('.playlist .playlist_item'); //get all playlist_item
            link_item.forEach(function(link) {
                if(link.classList.contains('active')){
                    link.classList.remove('active');
                }
            });
            item.classList.add('active');
            // end <-----

            let main_item = document.querySelectorAll('.video_wrapper .main_video'); //get all main video
            main_item.forEach(function(video_item){
                itemID = video_item.getAttribute('id');
                
                //replace video in main video section
                if(video_item.classList.contains('show_active')){
                    video_item.classList.remove('show_active')
                }
                if(itemID===url){
                    video_item.classList.add('show_active');
                 }

            });
        });

    });