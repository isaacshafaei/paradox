<?php
require_once 'plugins/searchwp-live-ajax-search/searchwp-live-ajax-search.php';

add_image_size('paradox-60x60', 60,60,true);
add_image_size('paradox-80x80', 80,80,true);
add_image_size('paradox-820x550', 820,550,true);
add_image_size('paradox-410x260', 410,260,true);
add_image_size('paradox-100x80', 100,80,true);
add_image_size('paradox-280x160', 280,160,true);

// Enqueue styles
function paradox_core_scripts() {
    wp_enqueue_style( 'plugin-style', plugin_dir_url( __FILE__ ).'../assets/css/danesh-core.css');

    wp_enqueue_script( 'jsparadox-core',plugin_dir_url( __FILE__ ) . '../assets/js/danesh-core.js', array("jquery"), '1.0.1', true );
}
add_action( 'wp_enqueue_scripts', 'paradox_core_scripts' );

function change_label_text($label_type){
    switch ($label_type) {
        case 'free':
            $result = 'رایگان';
            break;
        case 'video':
            $result = 'ویدیو';
            break;
        case 'exam':
            $result = 'آزمون';
            break;
        case 'quiz':
            $result = 'کوئیز';
            break;
        case 'lecture':
            $result = 'مقاله';
            break;
        case 'practice':
            $result = 'تمرین';
            break;
        case 'attachments':
            $result = 'فایل های ضمیمه';
            break;
        case 'sound':
            $result = 'فایل صوتی';
            break;    
    }
    return $result;
}

// Get Lesson Video Address Ajax

if(!function_exists('get_the_lesson_video_ajax')){
    function get_the_lesson_video_ajax(){

        $url=$_POST['url'];
        if($url){
            echo $url;
        }
        wp_die();
    }
}
add_action('wp_ajax_preview_video_ajax', 'get_the_lesson_video_ajax');

// get terms dropdown
  function get_the_product_category(){
    $cats = get_terms('product_cat');
    foreach ($cats as $categories) {
      $catid = $categories->term_id;
      $catsname = $categories->name;
     $orderoptions[$catid] = $catsname;
    }
    return $orderoptions;
  }

  //get the post category
  function get_the_post_category(){
    $cats_list = get_categories();
    foreach ($cats_list as $cat) {
        $catid = $cat->term_id;
        $catsname = $cat->name;
       $orderoptions[$catid] = $catsname;
      }
  
    return $orderoptions;
  }