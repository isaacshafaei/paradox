<?php
/**
 * Plugin Name: paradox Core
 * Description: This plugin related to paradox Theme.
 * Version:     1.0.1
 * Author:      Isaac Shafaei
 * Author URI:  https://kitwp.com/
 */
function add_paradox_widget_categories( $elements_manager ) {
	$elements_manager->add_category(
		'paradox-category',
		[
			'title' => esc_html__( 'المان های پارادوکس', 'paradox-core' ),
			'icon' => 'fa fa-plug',
		]
	);
	$elements_manager->add_category(
		'paradox-header-category',
		[
			'title' => esc_html__( 'المان های هدر پارادوکس', 'paradox-core' ),
			'icon' => 'fa fa-plug',
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'add_paradox_widget_categories' );

function register_paradox_widget( $widgets_manager ) {

	require_once( __DIR__ . '/widgets/lessons.php' );
	require_once( __DIR__ . '/widgets/ajax-search.php' );
	require_once( __DIR__ . '/widgets/course-carousel.php' );
	require_once( __DIR__ . '/widgets/blog.php' );
	require_once( __DIR__ . '/widgets/video-player.php' );
	require_once( __DIR__ . '/widgets/header/login-button.php' );
	require_once( __DIR__ . '/widgets/header/menu.php' );
	require_once( __DIR__ . '/widgets/course-list.php' );
	require_once( __DIR__ . '/widgets/cart-review.php' );
	require_once( __DIR__ . '/widgets/pelleh-blog.php' );
	require_once( __DIR__ . '/widgets/padcast.php' );

	$widgets_manager->register( new \Elementor_paradox_Lessons_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Search_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Course_Carousel_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Blog_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Video_Player_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Login_Button_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Menu_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Course_List_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Cart_Review_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Pelleh_Blog_Widget() );
	$widgets_manager->register( new \Elementor_paradox_Padcast_Widget() );

}
add_action( 'elementor/widgets/register', 'register_paradox_widget' );

include_once(dirname(__FILE__).'/inc/function.php');